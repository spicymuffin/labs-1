from math import factorial
cities = input("How many cities? ")
cities = int(cities)
print(f"For {cities} cities, there are {factorial(cities)} possible routes")