import random
# nothing special really just random ints
# i guess i made it look nice by using backslashes
print("Lotto numbers of the week:", \
      random.randint(1, 45), \
      random.randint(1, 45), \
      random.randint(1, 45), \
      random.randint(1, 45), \
      random.randint(1, 45), \
      random.randint(1, 45))
