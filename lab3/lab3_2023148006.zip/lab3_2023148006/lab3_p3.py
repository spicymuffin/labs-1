# this doesnt really need explanations i think 😅
print("# Fahrenheit to Celsius conversion program\n")
print("fahren = float(input('Enter degrees Fahrenheit: '))")
print("celsius = (fahren - 32) * 5 / 9")
print("print(fahren, 'degrees Fahrenheit equals',")
print("    format(celsius, '.1f'), 'degrees Celsius')")
# the output program runs as expected thats good at least