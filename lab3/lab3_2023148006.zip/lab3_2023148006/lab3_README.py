##############################################################################
# CCO1100-01 Lab 3                                                           #
# answers to questions                                                       #
##############################################################################

#
# Q1: please replace 'None' by your answer (integer):
#
q1_answer = 99

##############################################################################
# Grading code. Please do not touch any code below this line:                #
##############################################################################
SEP = '-' * 79
print(SEP)
print('CCO1100-01 Lab 3')
print('Answers to questions')
print(SEP)
print('Answer Q1:', q1_answer)
print(SEP)
