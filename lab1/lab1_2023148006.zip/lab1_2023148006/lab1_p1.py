print("Hello, world!")
print("My name is Luigi Cussigh!")